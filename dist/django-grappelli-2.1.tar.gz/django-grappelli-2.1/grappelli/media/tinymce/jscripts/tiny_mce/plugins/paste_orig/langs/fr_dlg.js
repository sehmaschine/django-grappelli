tinyMCE.addI18n('fr.paste_dlg',{
text_title:"Utilisez CTRL+V sur votre clavier pour coller le texte dans la fen\u00EAtre.",
text_linebreaks:"Conserver les retours \u00E0 la ligne",
word_title:"Utilisez CTRL+V sur votre clavier pour coller le texte dans la fen\u00EAtre."
});