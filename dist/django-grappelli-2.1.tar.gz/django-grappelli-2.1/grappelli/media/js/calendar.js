// NOTE grappelli: modification of original!
// not needed (use ui datepicker instead)